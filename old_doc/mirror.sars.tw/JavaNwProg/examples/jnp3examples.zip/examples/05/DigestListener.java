public interface DigestListener {

  public void digestCalculated(byte[] digest);

}
