import java.net.*;


public class DatagramSocketTest {

  public static void main(String[] args) throws Exception {
    DatagramSocket s = new DatagramSocket();
  
  }

}